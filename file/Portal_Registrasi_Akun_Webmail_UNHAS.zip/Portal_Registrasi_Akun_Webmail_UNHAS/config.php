<?php
$username = "vegavati_kp1";
$password = "123456789";
$host = "localhost";
$db = "vegavati_registrasidb";

mysql_connect($host, $username, $password) or die("cannot connect to database");

mysql_select_db($db) or die("database is not available");

?>