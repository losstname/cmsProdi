<?php
include "koneksi.php";
include "input_registrasi_dosen";
$sql = "SELECT * FROM reg_dosen WHERE kode_aktivasi = '$_GET[kode]'";
$hasil = mysql_query($sql);
$jumlah = mysql_num_rows($hasil);
 
if ($jumlah==1){
    $data=mysql_fetch_array($hasil);

mysql_query("UPDATE reg_dosen SET ket = 'Y' WHERE kode_aktivasi ='$_GET[kode]'");
echo "<script>window.alert('Akun anda sudah diaktifkan !'); window.location=('registrasi_dosen.php')</script>";
} else{
    echo "<script>window.alert('Kode aktivasi tidak ditemukan !, Klik ok untuk Kembali ke halaman awal'); window.location=('home.php')</script>";
}
?>