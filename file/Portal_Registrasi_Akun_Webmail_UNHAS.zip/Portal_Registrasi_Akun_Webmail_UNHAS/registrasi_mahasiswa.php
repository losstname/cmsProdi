<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/slider.css">
        <link rel="shortcut icon" href="img/favicon.png">
        <link rel="stylesheet" type="text/css" href="css/css-new.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/col.css">
		
        <link rel="stylesheet" media="all" type="text/css" href="css/2cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/3cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/4cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/5cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/6cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/480.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/768.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/1024.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/component.css">
        <link rel="shortcut icon" href="img/favicon.png">
        <script src="js/modernizr_custom.js"></script>
        <title>Registrasi Akun Webmail UNHAS</title>
		
    </head>
    <body>  
        
		<div id="navbar" class="group fluidwidth">
            <div class=" logo-wrapper col span_2_of_2">
                <div class="logo col logofluid"> <img src="img/toplogo.png"> </div>
                <div class="head col logofluid2"><p class="title"> Universitas Hasanuddin </p></div>
            </div>

            <div class='navbar col navbarwidth'>
                <ul>
                    <li><a href="home.php"> Home </a></li>
                    <li><a href="registrasi_dosen.php"> Registrasi Akun Webmail Dosen </a></li>
					<li class="selected"><a href="registrasi_mahasiswa.php"> Registrasi Akun Webmail Mahasiswa </a></li>
                </ul>
            </div>

            

            <div class='search-wrapper col'>

                <div class='dropdown col'>
					<div class="column">
						<div id="dl-menu" class="dl-menuwrapper">
							<button class="dl-trigger">Open Menu</button>
							<ul class="dl-menu">
								<li class="selected"><a href="home.php"> Home </a></li>
								<li><a href="registrasi_dosen.php"> Registrasi Akun Webmail Dosen </a></li>
								<li class="selected"><a href="registrasi_mahasiswa.php"> Registrasi Akun Webmail Mahasiswa </a></li>
							</ul>
						</div>
					</div>
				</div>
                
            </div>
            
        </div> 
        
		<div id="main" class="fluidwidth group">
			
			<div id='container-berita' class='grid_24'>
				<div class='judul-artikel'>
					<h2>REGISTRASI MAHASISWA</h2>
				</div>
				<form action="input_registrasi_mahasiswa.php" method="post">
				<div class='konten-artikel'>
					
						
						<span class="form-group"><label>First Name :</label></span>
						<br>
						<input name="first" type="text" required class="form-control" id="first" placeholder="Masukkan nama depan Anda" data-validation-required-message="Mohon Masukkan nama depan Anda">
						
						<br>
						<span class="form-group"><label>Last Name :</label></span>
						<br>
						<input name="last" type="text" required class="form-control" id="last" placeholder="Masukkan nama belakang Anda" data-validation-required-message="Mohon Masukkan nama belakang Anda">
						
						<br>
						<span class="form-group"><label>Nama Lengkap :</label></span>
                        <script>
function myFun() {
    
	var x = document.getElementById("first").value;
	var y = document.getElementById("last").value;
    document.getElementById("nama").value = x + " " + y; 
}
</script>
                       
						<button type="submit" onclick="myFun()" class="btn btn-default">Isi</button>
						<input name="nama" type="text" readonly required class="form-control" id="nama"  placeholder="Klik Button 'Isi' untuk Mengisi Nama Lengkap Anda" data-validation-required-message="Mohon Masukkan Nama Lengkap Anda">
						
						<br>
						<span class="form-group"><label>NIM :</label></span>
						<br>
						<input name="nim" type="text" required class="form-control" id="nim" placeholder="Masukkan NIM Anda" data-validation-required-message="Mohon Masukkan NIM Anda">
						
						<br>
						<span class="form-group"><label>No.Telepon/HP :</label></span>
                        <br>
						<input name="notelp" type="text" required class="form-control" id="notelp" placeholder="Masukkan No.Telepon/HP Anda" data-validation-required-message="Mohon Masukkan No.Telepon/HP Anda">
                        
						<br>
						<span class="form-group"><label>Fakultas :</label></span>
						<input name="fakultas" type="text" required class="form-control" id="fakultas" placeholder="Masukkan Fakultas Anda" data-validation-required-message="Mohon Masukkan Fakultas Anda">
                        
						<br>
						<span class="form-group"><label>Program Studi</label></span>
						<input name="prodi" type="text" class="form-control" placeholder="Masukkan program studi Anda" id="prodi" required data-validation-required-message="Mohon Masukkan Program Studi Anda">
                        
						<br>
						<span class="form-group"><label>Angkatan</label></span>
						<input name="agktan" type="text" class="form-control" placeholder="Masukkan angkatan Anda" id="agktan" required data-validation-required-message="Mohon Masukkan Angkatan Anda">
						
                        <br>
						<span class="form-group"><label>Akun Email Anda :</label></span>
                        <input name="email" type="email" class="form-control" placeholder="Masukkan Akun Email Anda" id="email" required data-validation-required-message="Mohon Masukkan Akun Email Anda">
                        
						<br>
                        <span class="form-group"><label>Akun UNHAS Anda :</label></span>
<script>
function myFunction() {
    
	var str = document.getElementById("first").value;
		var res = str.replace(" ",".");
		//var res = str.toLowerCase();
	var str1 = document.getElementById("last").value;
		var res1 = str1.replace(" ",".");
        var str2 = document.getElementById("nim").value;
		var res2 = str2.replace(" ",".");
		//var res1 = str1.toLowerCase();
	document.getElementById("username").value = res + "." + res1 + "." + res2 + "@studentunhas.ac.id";
	var str2 = document.getElementById("username").value;
	var res2 = str2.toLowerCase();
	document.getElementById("username").value = res2;
}
</script>
						<button type="submit" onclick="myFunction()" class="btn btn-default">Buat</button>
						<input name="username" type="email" class="form-control" readonly id="username" required placeholder="Klik Button 'Buat' untuk Membuat Akun" data-validation-required-message="Mohon Masukkan Akun UNHAS Anda">
                     
						<br>
						<span class="form-group"><label>Password :</label></span>
                        <input name="pswd" type="Password" class="form-control" placeholder="Masukkan Password Anda untuk Akun UNHAS Anda" id="pswd" required data-validation-required-message="Mohon Masukkan Password Anda">
                        
						<br>
						<p align="center">Silahkan klik &quot;Registrasi&quot; di bawah ini !</p>
						<p align="center">
							<button type="submit" class="btn btn-default btn-lg">Registrasi</button>
						</p>
					
					
				</div>
				</form>
			</div>
		</div>
        
        <footer class='fluidwidth group'>   
            <div id="footer-media" class='span_2_of_2'>
                <div class="">
                </div>
                <div class="nav-footer">
                    <center>Copyright ©2015 Universitas Hasanuddin</center>
                </div>
            </div>
        </footer>

        <script src="js/jquery.min.js"></script>
        <script src="js/jquery.dlmenu.js"></script>
        <script>
            $(function() {
                $( '#dl-menu' ).dlmenu();
            });
        </script>
</body>

</html>