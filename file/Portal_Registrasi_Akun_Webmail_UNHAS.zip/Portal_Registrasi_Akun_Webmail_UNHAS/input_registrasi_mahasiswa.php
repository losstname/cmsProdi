<?php
include "koneksi.php";

$username       = $_POST['username'];
$nama		= $_POST['nama'];
$email          = $_POST['email'];
$password       = $_POST['pswd'];
$nim            = $_POST['nim'];
$notelp         = $_POST['notelp']; 
$fakultas	= $_POST['fakultas'];
$kode           = md5(uniqid(rand(),true));
$cekData=mysql_num_rows(mysql_query("SELECT nim,nama,fakultas FROM tabel_mahasiswa WHERE nim = '$nim' && nama = '$nama' && fakultas = '$fakultas' "));
$cekEmail=mysql_num_rows(mysql_query("SELECT email_tujuan FROM reg_mahasiswa WHERE email_tujuan = '$email'"));

if ($cekData == 0){
  echo "<script>window.alert('Mohon maaf, NIM anda tidak terdaftar/tidak sesuai dalam database UNHAS !');
        window.location=('registrasi_mahasiswa.php')</script>";
}
elseif ($cekEmail > 0){
  echo "<script>window.alert('Mohon maaf, Email anda sudah terdaftar !');
        window.location=('registrasi_mahasiswa.php')</script>";
} 
else {

$kepada         = $_POST['email'];
$dari           = "kerjapraktik1@gmail.com";
//$pesan          = "Silahkan klik link aktivasi ini untuk mengaktifkan akun anda : http://kerjapraktek1.vegavatima.com/Registrasi_Akun_UNHAS/aktivasi.php?kode=$kode";
$pesan          = "Silahkan klik link aktivasi ini untuk mengaktifkan akun anda : http://kerjapraktek1.vegavatima.com/Portal_Registrasi_Akun_Webmail_UNHAS/aktivasi_akun_mahasiswa.php?kode=$kode";
$judul          = "Aktivasi Akun";

mysql_query("INSERT INTO reg_mahasiswa (nim, nama, notelp, fakultas, username, password, email_tujuan, kode_aktivasi, ket) VALUES ('$nim', '$nama', '$notelp', '$fakultas','$username', '$password', '$email', '$kode', 'N')") or die (mysql_error());

mail($email, $judul, $pesan, $dari);

echo "<script>window.alert('Pendaftaran berhasil, Silahkan Klik Link aktivasi yang telah kami kirim ke email anda!'); window.location=('registrasi_mahasiswa.php')</script>";
}
?>