<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/slider.css">
        <link rel="shortcut icon" href="img/favicon.png">
        <link rel="stylesheet" type="text/css" href="css/css-new.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/col.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/2cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/3cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/4cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/5cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/6cols.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/480.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/768.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/1024.css">
        <link rel="stylesheet" media="all" type="text/css" href="css/component.css">
        <link rel="shortcut icon" href="img/favicon.png">
        <script src="js/modernizr_custom.js"></script>
        <title>Registrasi Akun Webmail UNHAS</title>
		
    </head>
    <body>  
        
		<div id="navbar" class="group fluidwidth">
            <div class=" logo-wrapper col span_2_of_2">
                <div class="logo col logofluid"> <img src="img/toplogo.png"> </div>
                <div class="head col logofluid2"><p class="title"> Universitas Hasanuddin </p></div>
            </div>

            <div class='navbar col navbarwidth'>
                <ul>
                    <li class="selected"><a href="home.php"> Home </a></li>
                    <li><a href="registrasi_dosen.php"> Registrasi Akun Webmail Dosen </a></li>
					<li><a href="registrasi_mahasiswa.php"> Registrasi Akun Webmail Mahasiswa </a></li>
                </ul>
            </div>

            

            <div class='search-wrapper col'>

                <div class='dropdown col'>
					<div class="column">
						<div id="dl-menu" class="dl-menuwrapper">
							<button class="dl-trigger">Open Menu</button>
							<ul class="dl-menu">
								<li class="selected"><a href="home.php"> Home </a></li>
								<li><a href="registrasi_dosen.php"> Registrasi Akun Webmail Dosen </a></li>
								<li><a href="registrasi_mahasiswa.php"> Registrasi Akun Webmail Mahasiswa </a></li>
							</ul>
						</div>
					</div>
				</div>
                
            </div>
            
        </div> 
        
		<div id="main" class="fluidwidth group">
            
			<div id='container-berita' class='grid_24'>
				<center>
				
				<div class='judul-artikel'>
					<br>
					<br>
					<h2>REGISTRASI AKUN WEBMAIL UNHAS</h2>
				</div>
				<div class='konten-artikel'>
				<br>
					<br>
					<br>
					<p align="center">Silahkan Pilih Button Registrasi di bawah ini sesuai dengan status anda di Universitas Hasanuddin !</p>
					<p align="center">Atau anda dapat Memilih pada Menu di atas !</p>
                  <p align="center"><a href="registrasi_dosen.php" class="btn btn-default btn-lg">Registrasi Dosen</a>
                    <a href="registrasi_mahasiswa.php" class="btn btn-default btn-lg">Registrasi Mahasiswa</a>                  </p>
				</div>
				
				</center>
			</div> 
			
        </div>
        
        <footer class='fluidwidth group'>   
            <div id="footer-media" class='span_2_of_2'>
                <div class="">
                </div>
                <div class="nav-footer">
                    <center>Copyright ©2015 Universitas Hasanuddin</center>
                </div>
            </div>
        </footer>

        <script src="js/jquery.min.js"></script>
        <script src="js/jquery.dlmenu.js"></script>
        <script>
            $(function() {
                $( '#dl-menu' ).dlmenu();
            });
        </script>
</body>

</html>