<?php
include "koneksi.php";

$username       = $_POST['username'];
$nama		= $_POST['nama'];
$email          = $_POST['email'];
$password       = $_POST['pswd'];
$nip            = $_POST['nip'];
$notelp         = $_POST['notelp'];
$fakultas	= $_POST['fakultas'];
$kode           = md5(uniqid(rand(),true));
$cekDosen=mysql_num_rows(mysql_query("SELECT nip,nama,fakultas FROM tabel_dosen WHERE nip = '$nip' && nama = '$nama' && fakultas = '$fakultas' "));
$cekEmail=mysql_num_rows(mysql_query("SELECT email_tujuan FROM reg_dosen WHERE email_tujuan = '$email'"));

if ($cekDosen == 0){
  echo "<script>window.alert('Mohon maaf, NIP/NAMA/Fakultas anda tidak tercantum dalam Database Dosen/Staff UNHAS !');
        window.location=('registrasi_dosen.php')</script>";
}
elseif ($cekEmail > 0){
  echo "<script>window.alert('Mohon maaf, Email anda sudah terdaftar !');
        window.location=('registrasi_dosen.php')</script>";
}
else {
     
$kepada         = $_POST['email'];
$dari           = "kerjapraktik1@gmail.com";
$pesan          = "Silahkan klik link aktivasi ini untuk mengaktifkan akun anda : http://kerjapraktek1.vegavatima.com/Portal_Registrasi_Akun_Webmail_UNHAS/aktivasi_akun_dosen.php?kode=$kode";
$judul          = "Aktivasi Akun";

mysql_query("INSERT INTO reg_dosen (nip, nama, notelp, fakultas, username, password, email_tujuan, kode_aktivasi, ket) VALUES ('$nip', '$nama', '$notelp', '$fakultas','$username', '$password', '$email', '$kode', 'N')") or die (mysql_error());

mail($email, $judul, $pesan, $dari);

echo "<script>window.alert('Pendaftaran berhasil, Silahkan Klik Link aktivasi yang telah kami kirim ke email anda!'); window.location=('registrasi_dosen.php')</script>";
}
?>