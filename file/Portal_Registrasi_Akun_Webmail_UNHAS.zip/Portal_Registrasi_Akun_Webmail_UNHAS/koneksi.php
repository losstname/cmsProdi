<?php 
$host="localhost"; 
$user="vegavati_kp1"; 
$password="123456789"; 
$database="vegavati_registrasidb"; 
$koneksi=mysql_connect($host,$user,$password); 
mysql_select_db($database,$koneksi); 
//cek koneksi 
if($koneksi){ 
//echo "berhasil koneksi"; 
}else{ 
echo "gagal koneksi"; 
} 
?> 